<?php
session_start();
require("config.php");
if(!isset($_SESSION['username']))
{
    header('location: /login');
}

if ($user["level"]=="0"){
    $capdo="Thường";
}
if ($user["level"]=="1"){
    $capdo="Đại Lý";
}
if ($user["level"]=="3"){
    $capdo="ADMIN";
}
?>
<!DOCTYPE html>
<html lang="en">

<!--------------------------------------------------------|
| DỊCH VỤ THIẾT KẾ WEB NGUYỄN VŨ TRƯỜNG HUY               |
|       ZALO : 0369784374                                 |
|---------------------------------------------------------!>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <meta content="<?= $description; ?>" name="description" />
    
    <meta content="<?= $keywords; ?>" name="keywords" />
    
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?= $url_logo; ?>">
    <link rel="icon" type="image/x-icon" href="<?= $url_logo; ?>" />
    
    
    <title><?=$site_name?> - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/app.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require("sidebar.php"); ?>
        <!-- End of Sidebar -->

    <!-- Begin Page Content -->
                <div class="container-fluid">
