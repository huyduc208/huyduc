# firstChild

```php
firstChild () : object
```

Returns the first child of the root element.