# search_noise (protected)

```php
search_noise ( string $text ) : string
```

Find a single noise element by providing the noise placeholder text.

| Parameter | Description
| --------- | -----------
| `text`    | The noise placeholder to find.

Returns the original contents for the placeholder.